#include<iostream>
using namespace std;
int main()
{
    //declare variable
    int score;
    cout << "Enter score: " ;
    cin >> score;
    if (score >= 90)
    {
        cout << "grade is A" << endl; //grade A if score is between 90 _ 100
    }
    else if (score >= 80 )
    {
        cout << "grade is B" << endl; // grade B if score is 80_ 90
    }
    else if (score >= 70)
    {
        cout << "grade is C" << endl; //grade C if score is 70 _ 80
    }
    else if(score >= 60)
    {
        cout << "Grade is D" << endl; //grade D if score is 60 _ 70
    }
    else 
    {
        cout << "Grade is F" << endl; //grade F for score less than 60
    }
    return 0;
}
    