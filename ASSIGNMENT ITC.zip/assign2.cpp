#include<iostream>
using namespace std;
int main()
{
    int a, b, c;
    cout << "Enter the value of a: " ;
    cin >> a;
    cout << "Enter the value of b: " ;
    cin >> b;
    //output before swapping 
    cout << "Before swapping: " << "a= " << a << "  b= " << b << endl;
    //swapping the values
    c = a;
    a = b;
    b = c;
    // values after swapping 
    cout << "After swapping: " << endl;
    cout << "a =  " << a << "  b= " << b << endl;
    return 0;
}