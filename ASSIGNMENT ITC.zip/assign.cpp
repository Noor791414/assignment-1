#include<iostream>
using namespace std;
int main()
{
    int code;
    cout << "1" << '\t' << "Fish" << "\n" << "2" << '\t' <<"Chicken Karrahi" << "\n" << "3" << '\t' <<"Mutton Tikka" << "\n" << "4" << '\t' << "Daal Haleem" << "\n" << "5" << '\t' << "Sabzi" << endl;
    cout << "_______________________________________" << endl;
    cout<< "Enter the code for meal: "; // get th meal from the user
    cin>> code;
    if (code==1)
    {
        cout<< "Fish" << endl;
    }
    else if (code == 2)
    {
        cout << "Chicken karrahi" << endl;
    }
    else if (code == 3)
    {
        cout << "Mutton Tikka" << endl;
    }
    else if(code == 4)
    {
        cout << "daal Haleem" << endl;
    }
    else if(code == 5)
    {
        cout << "Sabzi" << endl;
    }
    else
    {
        cout << "ERROR: Select the code again"<< endl ;
    }
    double quantity;
    //input the quantity user wants to order
    cout << "Enter the quantity in kilograms: " << endl;
    cin >> quantity;
    cout << "____________________________" << endl;
    // use of conditional statements
    if (quantity <= 0)
    {
        cout << "ERROR: Enter the quantity again: " << endl;
    }
     // select the currency
    int num;
    cout <<"1"<< '\t' <<"PKR"<<"\n" <<"2"<< '\t' <<"EURO"<< "\n" <<"3"<< '\t' <<"DOLLAR" << endl;
    cout << "Enter the currency: " << endl;
    cin >> num;
    if(num == 1) // enter currency in pkr, euro or dollars
    {
        cout << "PKR" << endl;
    }
    else if(num == 2)
    {
        cout << "EURO" << endl;
    }
    else if(num == 3)
    {
        cout << "DOLLAR" << endl;
    }
    else 
    {
        cout<< "ERROR: ENTER THE CUURRENCY AGAIN" << endl; // error generated
    }
     cout << "__________________________________" << endl;
    const double fishPricePerKg = 1800;
    double chickenKarahiPricePerKg = 2000;
    double muttonTikkaPricePerKg = 2200;
    double daalHaleemPricePerKg = 500;
    double sabziPricePerKg = 250;
    int price;
    switch(code)
    {
        case 1:
        price = fishPricePerKg;
        cout << "The price of" << quantity << " fish: "<< quantity * fishPricePerKg << endl;
        break;
        case 2:
        price =chickenKarahiPricePerKg ;
        cout << "The price of" << quantity<< " chicken karahi:" << quantity * chickenKarahiPricePerKg << endl;
        break;
        case 3:
        price = muttonTikkaPricePerKg;
         cout << "The price of " << quantity << " muttonTikka"<< quantity * muttonTikkaPricePerKg << endl;
         break;
         price =  daalHaleemPricePerKg ;
         cout << "The price of " << quantity <<" daal Haleem" << quantity * daalHaleemPricePerKg << endl;
         break;
         price = sabziPricePerKg;
         cout << "The price of " << quantity << " sabzi " << quantity * sabziPricePerKg << endl;
         break;
    }
        // calculate the total price
        int totalPrice = price * quantity;
        // calculate salestax
         int salestax;
        double taxRate = 0.10;
         salestax = totalPrice * taxRate;
         cout << "Sales tax is: " << salestax << endl;
         // display the total amount for the customer
         int totalAmount;
         totalAmount = totalPrice + salestax;
         cout << "The total amount is: " << totalAmount << endl;
         const double PKR_TO_DOLLAR_RATE = 165; // Example conversion rate
         const double PKR_TO_EURO_RATE = 193;   // Example conversion rate
         double convertedAmount = totalAmount;
          int currencyOption;
    cout << "Enter the currency option for conversion (1 for PKR, 2 for EURO, 3 for DOLLAR): ";
    cin >> currencyOption;

    switch (currencyOption) {
        case 1: 
            // PKR, no conversion needed
            cout << "Total in PKR: " << totalAmount << " PKR" << endl;
            break;
        case 2: 
            // Convert to Euro
            convertedAmount = totalAmount / PKR_TO_EURO_RATE;
            cout << "Total in Euro: " << convertedAmount << " EUR" << endl;
            break;
        case 3: 
            // Convert to Dollar
            convertedAmount = totalAmount / PKR_TO_DOLLAR_RATE;
            cout << "Total in Dollar: " << convertedAmount << " USD" << endl;
            break;
        default:
            cout << "Invalid currency selection!" << endl;
            break;
    }

    return 0;
}